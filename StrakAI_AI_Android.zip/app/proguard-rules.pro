# Strak AI ProGuard/R8 rules.
