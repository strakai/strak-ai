# Strak AI — Android project

Готовый Android Studio проект для приложения Strak AI.

## Что внутри
- Android app module `app`
- Java Activity + WebView
- Тёмно-фиолетовый интерфейс Strak AI
- Новый чат, история, избранное, настройки
- Адаптация под телефоны
- Демо-ответы без API
- Разрешение INTERNET уже добавлено для будущего подключения настоящей ИИ-модели

## Как открыть
1. Установите Android Studio.
2. Распакуйте архив.
3. Откройте в Android Studio корневую папку `StrakAI`.
4. Дождитесь Gradle Sync.
5. Выберите `app`.
6. Нажмите Run для телефона/эмулятора или Build > Build APK(s).

## Важно
Проект использует Android Gradle Plugin 8.7.3 и compileSdk 35. Android Studio/SDK должны быть установлены и иметь соответствующий SDK Platform.

Сейчас ИИ работает как локальная демо-логика. Чтобы Strak AI стал настоящим ИИ-сервисом, нужно подключить backend/API и не хранить секретный API-ключ внутри APK.
